use classicmodels;
show tables;

select customers from classicmodels;


SET sql_safe_updates = 0;

UPDATE orders
SET comments = COALESCE(comments, 'no comments')
WHERE comments IS NULL;
select * from orders;
select * from classicmodels.customers;
UPDATE customers
SET phone = CONCAT('+', REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone, '.', ''), '-', ''), ' ', ''), '(', ''), ')', ''), '+', ''))
WHERE phone IS NOT NULL;

select * from classicmodels.customers;

